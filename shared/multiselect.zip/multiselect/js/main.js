$(function(){
    $(".chosen-select").chosen(); 
})